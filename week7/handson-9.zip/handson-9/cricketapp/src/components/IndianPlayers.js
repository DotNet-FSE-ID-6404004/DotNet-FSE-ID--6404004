import React from 'react';

const IndianPlayers = () => {
  
  const allPlayers = [
    "Virat", "Rohit", "Dhoni", "Gill", "Rahul",
    "Hardik", "Jadeja", "Bumrah", "Shreyas", "Pant"
  ];

  const oddTeam = allPlayers.filter((_, i) => i % 2 === 0);  // 0,2,4,...
  const evenTeam = allPlayers.filter((_, i) => i % 2 !== 0); // 1,3,5,...


  const [odd1, odd2, odd3] = oddTeam;
  const [even1, even2, even3] = evenTeam;


  const T20Players = ["Tilak", "Rinku"];
  const RanjiTrophyPlayers = ["Pujara", "Rahane"];
  const mergedPlayers = [...T20Players, ...RanjiTrophyPlayers];

  return (
    <div>
      <h2>Odd Team Players (Destructured)</h2>
      <p>{odd1}, {odd2}, {odd3}...</p>

      <h2>Even Team Players (Destructured)</h2>
      <p>{even1}, {even2}, {even3}...</p>

      <h3>Merged List of T20 & Ranji Trophy Players</h3>
      {mergedPlayers.map((player, index) => (
        <p key={index}>{player}</p>
      ))}
    </div>
  );
};

export default IndianPlayers;
