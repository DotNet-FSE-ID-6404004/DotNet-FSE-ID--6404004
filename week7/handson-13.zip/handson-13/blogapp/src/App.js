import React, { useState } from 'react';
import BookDetails from './BookDetails';
import BlogDetails from './BlogDetails';
import CourseDetails from './CourseDetails';

function App() {
  const [showBooks, setShowBooks] = useState(true);
  const [showBlogs, setShowBlogs] = useState(true);
  const [showCourses, setShowCourses] = useState(true);

  return (
    <div style={{ display: "flex", justifyContent: "space-around", fontFamily: "Arial" }}>
      
      {showCourses && <CourseDetails />}

      
      {showBooks ? <BookDetails /> : null}

      
      {
        (() => {
          if (showBlogs) {
            return <BlogDetails />;
          } else {
            return null;
          }
        })()
      }
    </div>
  );
}

export default App;
