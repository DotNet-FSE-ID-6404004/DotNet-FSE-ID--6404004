
import React from 'react';
import Img from './download.jpeg';
function App() {
  
  const heading = <h1 style={{ textAlign: "center" }}> Office Space Rental App</h1>;

  
  const singleOffice = {
    name: "DBS",
    rent: 55000,
    address: "Chennai",
    image: Img // Replace with your image path
  };

  
  const officeList = [
    { name: "MMD", rent: 45000, address: "Chennai", image: Img },
    { name: "MESTRO", rent: 72000, address: "Chennai", image:  Img},
    { name: "INK", rent: 60000, address: "Chennai", image: Img },
    { name: "EVA", rent: 80000, address: "Chennai", image: Img },
  ];

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      {heading}

      <div style={{ border: "1px solid gray", padding: "10px", marginBottom: "20px" }}>
        <img src={singleOffice.image} alt="Office" width={300} />
        <h2>{singleOffice.name}</h2>
        <p>Address: {singleOffice.address}</p>
        <p style={{ color: singleOffice.rent < 60000 ? "red" : "green" }}>
          Rent: ₹{singleOffice.rent}
        </p>
      </div>

      
      {officeList.map((office, index) => (
        <div key={index} style={{ border: "1px solid gray", padding: "10px", marginBottom: "20px" }}>
          <img src={office.image} alt={office.name} width={300} />
          <h2>{office.name}</h2>
          <p>Address: {office.address}</p>
          <p style={{ color: office.rent < 60000 ? "red" : "green" }}>
            Rent: ₹{office.rent}
          </p>
        </div>
      ))}
    </div>
  );
}

export default App;
