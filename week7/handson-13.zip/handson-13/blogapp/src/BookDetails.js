import React from 'react';

function BookDetails() {
  const books = [
    { title: "Master React", price: 670 },
    { title: "Deep Dive into Angular 11", price: 800 },
    { title: "Mongo Essentials", price: 450 }
  ];

  return (
    <div style={{ padding: 10, borderRight: "4px solid green" }}>
      <h2>Book Details</h2>
      {books.map((b, index) => (
        <div key={index}>
          <strong>{b.title}</strong><br />
          {b.price}
        </div>
      ))}
    </div>
  );
}

export default BookDetails;
