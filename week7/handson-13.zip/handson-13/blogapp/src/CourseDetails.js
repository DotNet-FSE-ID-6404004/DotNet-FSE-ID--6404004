import React from 'react';

function CourseDetails() {
  const courses = [
    { name: "Angular", date: "4/5/2021" },
    { name: "React", date: "6/3/2021" }
  ];

  return (
    <div style={{ padding: 10, borderRight: "4px solid green" }}>
      <h2>Course Details</h2>
      {courses.map((c, index) => (
        <div key={index}>
          <strong>{c.name}</strong><br />
          {c.date}
        </div>
      ))}
    </div>
  );
}

export default CourseDetails;
