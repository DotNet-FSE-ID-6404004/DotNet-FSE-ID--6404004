import React from 'react';

function UserPage({ onLogout }) {
  return (
    <div>
      <h1>Welcome back</h1>
      <p>Welcome User! You can now book your tickets.</p>
      <button onClick={onLogout}>Logout</button>
    </div>
  );
}

export default UserPage;
