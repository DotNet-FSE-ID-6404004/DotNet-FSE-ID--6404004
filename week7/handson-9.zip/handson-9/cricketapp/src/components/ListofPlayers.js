const ListofPlayers = () => {
  const players = [
    { name: "Virat", score: 85 },
    { name: "Rohit", score: 95 },
    { name: "Dhoni", score: 60 },
    { name: "Gill", score: 40 },
    { name: "Rahul", score: 75 },
    { name: "Hardik", score: 50 },
    { name: "Jadeja", score: 30 },
    { name: "Bumrah", score: 80 },
    { name: "Shreyas", score: 65 },
    { name: "Pant", score: 55 },
    { name: "Surya", score: 92 }
  ];

  const lowScorers = players.filter(player => player.score < 70);

  return (
    <div>
      <h2>All 11 Players</h2>
      {players.map((player, index) => (
        <p key={index}>{player.name}: {player.score}</p>
      ))}

      <h3>Players with Score below 70</h3>
      {lowScorers.map((player, index) => (
        <p key={index}>{player.name}: {player.score}</p>
      ))}
    </div>
  );
};

export default ListofPlayers;
